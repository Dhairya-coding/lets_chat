const firebaseConfig = {
  apiKey: "AIzaSyA6HG2s68EuVyGHA3PtX-jo37lEvADIuFE",
  authDomain: "lets-chat-6c366.firebaseapp.com",
  databaseURL: "https://lets-chat-6c366-default-rtdb.firebaseio.com",
  projectId: "lets-chat-6c366",
  storageBucket: "lets-chat-6c366.appspot.com",
  messagingSenderId: "306154151344",
  appId: "1:306154151344:web:c1f416d920cebf6c68ca75"
};

user_name = document.getElementById("user_name");

localStorage.setItem("user_name", user_name);
user_name = localStorage.getItem("user_name");

firebase.initializeApp(firebaseConfig);

function login() {
    user_name = document.getElementById("user_name").value;
    localStorage.setItem("user_name", user_name);
    window.location = "2LetsChat.html";

    firebase.database().ref("/").child(user_name).update({
        purpose : "adding User"
    });
 }